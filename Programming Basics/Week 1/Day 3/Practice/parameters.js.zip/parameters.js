function greet(name){
var t=15
if (name == "Count Dooku"){
    console.log("I'm coming for you, Dooku!")
}

else{
if (t>=5&&t<=12){
console.log("good morning "+name)};
    if (t>=12&&t<=18){
    console.log("good afternoon "+name);
}

else { console.log("good evening "+name);

}
}
}
 greet("tasnime")
